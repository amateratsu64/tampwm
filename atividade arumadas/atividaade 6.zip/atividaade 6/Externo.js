document.write('aoba java foi')
alert("Gotë ujë")